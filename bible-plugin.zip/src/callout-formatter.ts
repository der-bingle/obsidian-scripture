import { Editor } from 'obsidian';
import type { BibleVerse, BibleReferenceSettings } from './types';

export class CalloutFormatter {
	private settings: BibleReferenceSettings;

	constructor(settings: BibleReferenceSettings) {
		this.settings = settings;
	}

	insertScriptureCallout(editor: Editor, reference: string, verses: BibleVerse[], translation: string): void {
		const cursor = editor.getCursor();
		const callout = this.formatCallout(reference, verses, translation);

		const startPos = cursor;
		editor.replaceRange(callout, startPos);

		// Calculate end position based on the inserted text
		const endPos = {
			line: startPos.line + callout.split('\n').length - 1,
			ch: 0
		};

		editor.setCursor(endPos);
	}

	private formatCallout(reference: string, verses: BibleVerse[], translation: string): string {
		const versesText = verses.map((verse, index) => {
			const verseNum = verse.verse;
			// Join multiple content lines with newlines
			let content = verse.content.join('\n');

			// If it's poetry, add an extra newline at the end
			if (verse.poetry) {
				content += '\n';
			}

			// Handle verse numbers based on setting
			let versePrefix = '';
			if (this.settings.verseNumbers === 'include') {
				versePrefix = `<sup>${verseNum}</sup> `;
			} else if (this.settings.verseNumbers === 'exclude-first' && index > 0) {
				versePrefix = `<sup>${verseNum}</sup> `;
			}
			// For 'exclude', no prefix is added

			return `${versePrefix}${content}`;
		}).join(' ');

		// Split the verses text into lines and prefix each with "> "
		const calloutLines = versesText.split('\n').map(line => `> ${line}`).join('\n');

		// Include translation in the header
		const header = translation ? `${reference} (${translation})` : reference;

		return `> [!scripture] ${header}
${calloutLines}

`;
	}

	updateSettings(settings: BibleReferenceSettings): void {
		this.settings = settings;
	}
}
