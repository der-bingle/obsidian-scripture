import { App, Modal, Setting, TFile } from 'obsidian';
import { BibleReferenceSettings, BibleTranslation, BibleVerse } from './types';
import { BibleDataLoader } from './bible-data-loader';
import { CalloutFormatter } from './callout-formatter';
import { parseReference } from './bible-references/parse-reference';

export class BibleReferenceModal extends Modal {
    private referenceInput: HTMLInputElement;
    private previewEl: HTMLElement;
    private selectedTranslation: string;
    private settings: BibleReferenceSettings;
    private dataLoader: BibleDataLoader;
    private formatter: CalloutFormatter;
    private initialSelection: string;

    constructor(
        app: App,
        settings: BibleReferenceSettings,
        dataLoader: BibleDataLoader,
        initialSelection?: string
    ) {
        super(app);
        this.settings = settings;
        this.dataLoader = dataLoader;
        this.formatter = new CalloutFormatter(settings);
        this.selectedTranslation = settings.defaultTranslation;
        this.initialSelection = initialSelection || '';
    }

    onOpen() {
        const { contentEl } = this;
        contentEl.empty();

        contentEl.createEl('h2', { text: 'Insert Bible Reference' });

        // Translation selector
        this.createTranslationSelector();

        // Reference input
        const inputContainer = contentEl.createDiv('bible-reference-input-container');

        new Setting(inputContainer)
            .setName('Reference')
            .setDesc('Enter reference (e.g., "John 3:16", "Psalm 23:1-6")')
            .addText(text => {
                this.referenceInput = text.inputEl;
                text.setValue(this.initialSelection);
                text.onChange(async () => {
                    await this.updatePreview();
                });

                // Handle Enter key
                text.inputEl.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        this.insertReference();
                    }
                });
            });

        // Preview section
        const previewContainer = contentEl.createDiv('bible-reference-preview-container');
        previewContainer.createEl('h3', { text: 'Preview' });
        this.previewEl = previewContainer.createDiv('bible-reference-preview');

        // Buttons
        const buttonContainer = contentEl.createDiv('bible-reference-buttons');

        const insertBtn = buttonContainer.createEl('button', { text: 'Insert' });
        insertBtn.classList.add('mod-cta');
        insertBtn.addEventListener('click', () => this.insertReference());

        const cancelBtn = buttonContainer.createEl('button', { text: 'Cancel' });
        cancelBtn.addEventListener('click', () => this.close());

        // Initial preview update
        if (this.initialSelection) {
            this.updatePreview();
        }

        // Focus the input
        setTimeout(() => {
            this.referenceInput.focus();
            if (this.initialSelection) {
                this.referenceInput.select();
            }
        }, 100);
    }

    private createTranslationSelector() {
        const { contentEl } = this;

        if (this.settings.translations.length === 0) {
            const notice = contentEl.createDiv('bible-reference-notice');
            notice.innerHTML = `
                <p><strong>No translations configured</strong></p>
                <p>Please add Bible translations in Settings → Bible Reference to get started.</p>
            `;
            return;
        }

        const translationContainer = contentEl.createDiv('bible-reference-translations');
        translationContainer.createEl('h3', { text: 'Translation' });

        const buttonContainer = translationContainer.createDiv('bible-translation-buttons');

        this.settings.translations.forEach(translation => {
            if (!translation.isValid) return;

            const button = buttonContainer.createEl('button', {
                text: translation.name,
                cls: 'bible-translation-btn'
            });

            if (translation.name === this.selectedTranslation) {
                button.classList.add('is-selected');
            }

            button.addEventListener('click', async () => {
                // Update selection
                this.selectedTranslation = translation.name;

                // Update button states
                buttonContainer.querySelectorAll('.bible-translation-btn').forEach(btn => {
                    btn.classList.remove('is-selected');
                });
                button.classList.add('is-selected');

                // Update preview
                await this.updatePreview();
            });
        });
    }

    private async updatePreview() {
        if (!this.previewEl || !this.referenceInput.value.trim()) {
            if (this.previewEl) {
                this.previewEl.empty();
                this.previewEl.createEl('p', {
                    text: 'Enter a reference to see preview',
                    cls: 'bible-preview-placeholder'
                });
            }
            return;
        }

        try {
            const reference = this.referenceInput.value.trim();
            const translation = this.settings.translations.find(t => t.name === this.selectedTranslation);

            if (!translation) {
                this.showPreviewError('No translation selected');
                return;
            }

            // Parse the reference
            const parsedRefs = parseReference(reference);
            if (parsedRefs.length === 0) {
                this.showPreviewError('Invalid reference format');
                return;
            }

            // Load verses
            const verses = await this.dataLoader.getVerses(translation.name, parsedRefs);
            if (verses.length === 0) {
                this.showPreviewError('No verses found for this reference');
                return;
            }

            // Format as callout for preview
            const calloutText = this.formatter.formatAsCallout(verses, reference, translation.name);

            // Create preview that matches the actual output
            this.renderCalloutPreview(calloutText);

        } catch (error) {
            console.error('Preview error:', error);
            this.showPreviewError(`Error: ${error.message}`);
        }
    }

    private renderCalloutPreview(calloutText: string) {
        this.previewEl.empty();

        // Split the callout into lines and render properly
        const lines = calloutText.split('\n');
        const previewContainer = this.previewEl.createDiv('bible-callout-preview');

        lines.forEach((line, index) => {
            if (index === 0) {
                // First line is the callout header
                const headerEl = previewContainer.createDiv('bible-callout-header');
                headerEl.innerHTML = line.replace('> [!scripture] ', '').trim();
                headerEl.style.fontWeight = 'bold';
                headerEl.style.color = 'var(--text-accent)';
                headerEl.style.marginBottom = '0.5em';
            } else if (line.trim().startsWith('> ')) {
                // Content lines
                const contentEl = previewContainer.createDiv('bible-callout-content');
                const cleanLine = line.replace(/^>\s*/, '');

                if (cleanLine.trim() === '') {
                    // Empty line for spacing
                    contentEl.innerHTML = '&nbsp;';
                    contentEl.style.height = '0.5em';
                } else {
                    // Process the line to handle verse numbers and formatting
                    contentEl.innerHTML = cleanLine;
                }

                contentEl.style.marginLeft = '1em';
                contentEl.style.lineHeight = '1.6';
            }
        });

        // Style the preview container to look like a callout
        previewContainer.style.border = '1px solid var(--background-modifier-border)';
        previewContainer.style.borderRadius = '6px';
        previewContainer.style.padding = '1em';
        previewContainer.style.backgroundColor = 'var(--background-secondary)';
        previewContainer.style.borderLeftColor = 'var(--text-accent)';
        previewContainer.style.borderLeftWidth = '4px';
    }

    private showPreviewError(message: string) {
        this.previewEl.empty();
        const errorEl = this.previewEl.createEl('p', {
            text: message,
            cls: 'bible-preview-error'
        });
        errorEl.style.color = 'var(--text-error)';
        errorEl.style.fontStyle = 'italic';
    }

    private async insertReference() {
        const reference = this.referenceInput.value.trim();
        if (!reference) {
            return;
        }

        try {
            const translation = this.settings.translations.find(t => t.name === this.selectedTranslation);
            if (!translation) {
                throw new Error('No translation selected');
            }

            // Parse and load verses
            const parsedRefs = parseReference(reference);
            if (parsedRefs.length === 0) {
                throw new Error('Invalid reference format');
            }

            const verses = await this.dataLoader.getVerses(translation.name, parsedRefs);
            if (verses.length === 0) {
                throw new Error('No verses found for this reference');
            }

            // Format as callout
            const calloutText = this.formatter.formatAsCallout(verses, reference, translation.name);

            // Insert into editor
            const activeView = this.app.workspace.getActiveViewOfType('markdown');
            if (activeView && activeView.editor) {
                const cursor = activeView.editor.getCursor();
                activeView.editor.replaceRange(calloutText + '\n\n', cursor);
            }

            this.close();

        } catch (error) {
            console.error('Insert error:', error);
            // Could show a notice to user here
            new Notice(`Error inserting reference: ${error.message}`);
        }
    }

    onClose() {
        const { contentEl } = this;
        contentEl.empty();
    }
}
